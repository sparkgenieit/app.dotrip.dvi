// next.config.js
module.exports = {
  reactStrictMode: true,
  // other valid config options
};